#pragma once
#include "Route.h"
class Population
{
private:
	int populationSize = 50;
	std::vector <Route> routes = std::vector <Route>(populationSize);
public:
	Population(int size);
	Population(std::string fileName);
	~Population();
	void setRoute(int intex, Route route);
	int getSize();
	std::vector <Route> & getRoutes();
	void sortByFitness();
};

