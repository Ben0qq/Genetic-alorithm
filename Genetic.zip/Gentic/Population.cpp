#include "pch.h"
#include "Population.h"

Population::Population(int size)
{
	routes = std::vector <Route>(size);
}

Population::Population(std::string fileName)
{
	for (int i = 0; i < populationSize; i++)
	{
		routes[i] = Route(fileName);
	}
}

Population::~Population()
{
}

int Population::getSize()
{
	return populationSize;
}

void Population::setRoute(int index, Route route)
{
	routes[index] = route;
}

std::vector <Route> & Population::getRoutes()
{
	return routes;
}

void Population::sortByFitness()
{
	std::sort(routes.begin(), routes.end(), 
		[](Route& route1, Route& route2) ->bool
		{
			return route1.getFitness() > route2.getFitness();
		});
}
