#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <algorithm>
#include <random>
#include <string>
class Route
{
private:
	int vectorLength;
	double fitness = 0;
	std::string fileName;
	std::vector <std::vector<int>> values;
	std::vector<int> permutation;
public:
	Route();
	Route(std::string fileName);
	~Route();
	void setPermutation(std::vector<int> permutation);
	void setPermutation(int index, int element);
	std::vector<int> getPermutation();
	int getVectorLength();
	void setFileName(std::string fileName);
	void swap(int place1, int place2);
	int countLength();
	bool loadFromFile();
	void generatePermutation();
	double getFitness();
};
