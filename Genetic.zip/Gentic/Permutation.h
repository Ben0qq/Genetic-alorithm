#pragma once
class Permutation
{
public:
	Permutation();
	~Permutation();
};

