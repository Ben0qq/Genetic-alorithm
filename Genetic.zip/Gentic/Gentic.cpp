
#include "pch.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <algorithm>
#include <random>
#include "Genetic.h"
#include "czas.h"
int main()
{
	srand(time(NULL));
	std::vector<int> permutation;
	std::string fileName = "data58.txt";
	czas czas;
	std::fstream plik;
	plik.open("wyniki.txt", std::ios::out);
	float srednia = 0;
	float sredniBlad = 0;
	double mutationRate = 0.15;
	int tournamentSize = 15;
	int generations = 100;
	int eliteRoutes = 4;
	Genetic genetic;
	genetic	= Genetic(fileName);
	for (int j = 2; j < 3; j++)
	{
		czas.czasStart();
		genetic.Start();
		czas.czasStop();
		permutation = genetic.getBestPermutation();
		srednia *= (j - 1);
		srednia += czas.czasWykonania();
		srednia /= j;
		sredniBlad *= (j - 1);
		Route route = Route();
		route.setPermutation(permutation);
		sredniBlad += ((float)route.countLength() / 25395) - 1;
		sredniBlad /= j;
	}
	plik << sredniBlad << "		" << srednia << "		" << mutationRate << "		" << tournamentSize << "		" <<eliteRoutes<<"		"<< generations << "  " << fileName << std::endl;
	srednia = 0;
	genetic = Genetic(fileName);
	sredniBlad = 0;
	mutationRate = 1.0;
	return 0;
}
