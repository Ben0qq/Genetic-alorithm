#include "pch.h"
#include "Route.h"


Route::Route()
{
	std::string fileName = "data58.txt";
	setFileName(fileName);
	loadFromFile();
	permutation = std::vector<int>(vectorLength);
	generatePermutation();
	std::random_shuffle(permutation.begin(), permutation.end());
}

Route::Route(std::string fileName)
{
	setFileName(fileName);
	loadFromFile();
	permutation = std::vector<int>(vectorLength);
	generatePermutation();
	std::random_shuffle(permutation.begin(), permutation.end());
}

Route::~Route()
{
}
void Route::setPermutation(std::vector<int> permutation)
{
	this->permutation = permutation;
}
void Route::setPermutation(int index, int element)
{
	this->permutation[index] = element;
}
std::vector<int> Route::getPermutation()
{
	return this->permutation;
}

int Route::getVectorLength()
{
	return vectorLength;
}

void Route::setFileName(std::string fileName)
{
	this->fileName = fileName;
}

void Route::swap(int place1, int place2)
{
	int box;
	box = permutation[place1];
	permutation[place1] = permutation[place2];
	permutation[place2] = box;
}

int Route::countLength()
{
	int pathValue = 0;
	for (int i = 0; i < vectorLength - 1; i++)
	{
		pathValue += values[permutation[i]][permutation[i + 1]];
	}
	pathValue += values[permutation[vectorLength - 1]][permutation[0]];

	return pathValue;
}

bool Route::loadFromFile()
{
	int value;
	std::ifstream inFile;
	inFile.open(fileName, std::ios::in);
	if (inFile.is_open() == false)
		return false;
	inFile >> fileName;
	inFile >> vectorLength;
	this->vectorLength = vectorLength;
	values = std::vector<std::vector<int>>(vectorLength, std::vector<int>(vectorLength, 0));
	for (int i = 0; i < vectorLength; i++)
	{
		for (int j = 0; j < vectorLength; j++)
		{
			inFile >> value;
			values[i][j] = value;
		}
	}
	return true;
}

void Route::generatePermutation()
{
	for (int i = 0; i < vectorLength; i++)
	{
		permutation[i] = i;
	}
}

double Route::getFitness()
{
	fitness = (1 / (double)countLength()) * 10000;
	return fitness;
}
