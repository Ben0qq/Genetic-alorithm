#include "pch.h"
#include "Genetic.h"


Genetic::Genetic()
{
}

Genetic::Genetic(std::string fileName)
{
	this->fileName = fileName;
}

Genetic::~Genetic()
{
}

int Genetic::getBestRoute()
{
	return this->bestRoute;
}
void Genetic::setMutationRate(double rate)
{
	this->mutationRate = rate;
}
void Genetic::setTournamentSize(int size)
{
	this->tournamentSize = size;
}
void Genetic::setGenerations(int generations)
{
	this->generations = generations;
}
void Genetic::setEliteRoutes(int routes)
{
	this->eliteRoutes = routes;
}
std::vector<int> Genetic::getBestPermutation()
{
	return this->bestPermutation;
}
Population Genetic::crossoverPopulation(Population population)
{ 
	Population crossoverPopulation = population;
	for (int i = 0; i <eliteRoutes ; i++)
	{
		crossoverPopulation.setRoute(i, population.getRoutes()[i]);
	}
	for (int i = eliteRoutes; i < crossoverPopulation.getSize(); i++)
	{
		Route route1 = selectTournament(population).getRoutes()[0];
		Route route2 = selectTournament(population).getRoutes()[0];
		crossoverPopulation.setRoute(i,crossoverRoute(route1, route2));
	}
	return crossoverPopulation;
}

Population Genetic::mutatePopulation(Population population)
{
	for (int i = eliteRoutes; i < population.getSize(); i++)
	{
		double random = (double)rand() / RAND_MAX;
		if (random < mutationRate)
		{
			mutateRoute(population.getRoutes()[i]);
		}
	}
	return population;
}

Route Genetic::crossoverRoute(Route route1, Route route2)
{
	Route temp1 = route1;
	temp1.setPermutation(std::vector<int>(route1.getVectorLength(), -1));
	Route temp2 = route2;
	temp2.setPermutation(std::vector<int>(route1.getVectorLength(), -1));
	int separator1, separator2;
	separator1 = rand() % route1.getVectorLength();
	separator2 = rand() % route1.getVectorLength();
	while (separator1 >= separator2)
	{
		separator1 = rand() % route1.getVectorLength();
		separator2 = rand() % route1.getVectorLength();
	}
	std::vector<int> tempcheck1 = std::vector<int>(separator2-separator1, -1);
	std::vector<int> tempcheck2 = std::vector<int>(separator2-separator1, -1);
	for (int i = 0; i < route1.getVectorLength(); i++)
	{
		temp1.setPermutation(i,route1.getPermutation()[i]);
		temp2.setPermutation(i, route2.getPermutation()[i]);
	}
	for (int i = separator1; i < separator2; i++)
	{
		route2.setPermutation(i, temp1.getPermutation()[i]);
		route1.setPermutation(i, temp2.getPermutation()[i]);
		tempcheck1[i-separator1] = temp2.getPermutation()[i];
		tempcheck2[i-separator1] = temp1.getPermutation()[i];
	}
	std::vector<int> goodValues1 = std::vector<int>(0, -1);
	std::vector<int> goodValues2 = std::vector<int>(0, -1);
	for (int i = separator2; i < route1.getVectorLength(); i++)
	{
		if (std::find(tempcheck1.begin(), tempcheck1.end(), temp1.getPermutation()[i]) == tempcheck1.end())
		{
			goodValues1.push_back(temp1.getPermutation()[i]);
		}
		if (std::find(tempcheck2.begin(), tempcheck2.end(), temp2.getPermutation()[i]) == tempcheck2.end())
		{
			goodValues2.push_back(temp2.getPermutation()[i]);
		}

	}
	for (int i = 0; i < separator2; i++)
	{
		if (std::find(tempcheck1.begin(), tempcheck1.end(), temp1.getPermutation()[i]) == tempcheck1.end())
		{
			goodValues1.push_back(temp1.getPermutation()[i]);
		}
		if (std::find(tempcheck2.begin(), tempcheck2.end(), temp2.getPermutation()[i]) == tempcheck2.end())
		{
			goodValues2.push_back(temp2.getPermutation()[i]);
		}
	}
	int j = 0;
	for (int i = separator2 ; i < route1.getVectorLength(); i++)
	{
		route1.setPermutation(i, goodValues1[j]);
		route2.setPermutation(i, goodValues2[j]);
		j++;
	}
	for (int i = 0; i < separator1; i++)
	{
		route1.setPermutation(i, goodValues1[j]);
		route2.setPermutation(i, goodValues2[j]);
		j++;
	}
	if (route1.countLength()<route2.countLength())
		return route1;
	else
		return route2;
}

Route Genetic::mutateRoute(Route route)
{
	std::cout << std::endl;
	int x1 = 0, x2 = 0;
	x1 = rand() % route.getVectorLength();
	x2 = rand() % route.getVectorLength();
	while (x1 == x2)
	{
		x1 = rand() % route.getVectorLength();
		x2 = rand() % route.getVectorLength();
	}
	route.swap(x1, x2);
	return route;
}

Population Genetic::selectTournament(Population population)
{
	Population tournamentPopulation = Population(tournamentSize);
	int x;
	for (int i = 0; i < tournamentSize; i++)
	{
		x = rand() % population.getSize();
		tournamentPopulation.setRoute(i,population.getRoutes()[x]);
	}
	tournamentPopulation.sortByFitness();
	/*for (int i = 0; i < tournamentSize; i++)
	{
		std::cout << tournamentPopulation.getRoutes()[i].getFitness() << "\t";
	}
	*/
	return tournamentPopulation;
}

void Genetic::findBest(Population population)
{
	for (int i = 0; i < population.getSize(); i++)
	{
		if (population.getRoutes()[i].countLength() < bestRoute)
		{
			bestRoute = population.getRoutes()[i].countLength();
			bestPermutation = population.getRoutes()[i].getPermutation();
		}

	}
}

void Genetic::findBest(Route route)
{
	if (route.countLength() < bestRoute)
	{
		bestRoute = route.countLength();
		bestPermutation = route.getPermutation();
	}
}

std::vector<int> Genetic::Start()
{
	Population population = Population(fileName);
	population.sortByFitness();
	int generationCount = 0;
	while (generationCount < generations)
	{
		population = mutatePopulation(crossoverPopulation(population));
		population.sortByFitness();
		findBest(population.getRoutes()[0]);
		generationCount++;
		std::cout << generationCount << "\t";
	}
	return population.getRoutes()[0].getPermutation();
 }