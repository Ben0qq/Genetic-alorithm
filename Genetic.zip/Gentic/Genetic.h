#pragma once
#include "Population.h"
class Genetic
{
private:
	std::string fileName;
	double mutationRate = 0.15;
	int tournamentSize = 15;
	int generations = 100;
	int eliteRoutes = 4;
	int bestRoute = INT_MAX;
	std::vector<int> bestPermutation;
public:
	Genetic();
	Genetic(std::string fileName);
	~Genetic();
	int getBestRoute();
	void setMutationRate(double rate);
	void setTournamentSize(int size);
	void setGenerations(int generations);
	void setEliteRoutes(int routes);
	std::vector<int> getBestPermutation();
	Population crossoverPopulation(Population population);
	Population mutatePopulation(Population population);
	Route crossoverRoute(Route route1, Route route2);
	Route mutateRoute(Route route);
	Population selectTournament(Population population);
	void findBest(Population population);
	void findBest(Route route);
	std::vector<int> Start();
};

